const express = require("express")
const minimist = require('minimist')                    //Setting up
const fs = require('fs')
const path = require('path')
const { dirname } = require('path/posix')

const app = express()
const port = 3000


const { addUser, buyItem } = require('./temp.js')               //Pull in functions

app.listen(port)


app.set('views', path.join(__dirname, 'views'))
app.set('view engine', 'ejs')

app.use(express.urlencoded({ extended: true }))
app.use(express.static('public'))



function readUsers() {
    //Reading in user.json file
    let inputFile = fs.readFileSync('users.json').toString()
    let users = JSON.parse(inputFile)
    return users
}



app.get('/', (req, res) => {
    res.render('homepage.ejs')                                      //Default homepage
})

app.post('/login', (req, res) => {
    let users = readUsers()
    let userName = req.body.userName
    for (let i = 0; i < users.length; i++) {
        if (users[i].userName === req.body.userName) {             //Login route, check if the name exists and if so redirect to page, else go to homepage
            exists = true;
            res.redirect('/user/' + userName)
        } else {
            res.redirect('/')
        }
    }



})

app.get('/logout', (req, res) => {
    res.redirect('/')               //On logout button click redirect to main page
})

app.get('/user/:userName', (req, res) => {              //Get current users username to display in url

    let users = readUsers()
    let userName = req.params.userName
    console.log(userName)
    let user = null;

    for (let i = 0; i < users.length; i++) {
        if (users[i].userName === userName) {               //Loop through users array and find correct username that matches correctly
            user = users[i]
            users.splice(i, 1)
        }
    }
    res.render('login.ejs', { users: users, user: user })           //Render login page with correct users and user information
})

app.post('/register', (req, res) => {               //Register route
    let users = readUsers()

    let exists = false;

    for (let i = 0; i < users.length; i++) {                    //Check if the username exists by looping through array
        if (users[i].userName === req.body.userName) {
            exists = true;
        }
    }

    if (!exists) {
        addUser({ userName: req.body.userName, name: req.body.name, balance: req.body.balance })        //If not exist, add the user and their information
        res.redirect('/user/' + req.body.userName)
    }
    else {
        res.redirect('/')               //Else redirect to home page
    }
})


app.post('/buy', (req, res) => {
    console.log(req.body)
    buyItem({ id: Number(req.body.id), buyer: req.body.buyer })         //Handles buying route
    res.redirect('/user/' + req.body.buyer)                             //Redirects user to the their page and adds item
})


let args = minimist(process.argv.slice(2), {})
if ('addUser' in args) {
    addUser(args)
} else if ('addItem' in args) {
    addItems(args)
} else if ('buyItem' in args) {
    buyItem(args)                                   //These are the node.js commands. 
}                                                   
else if ('view' in args) {
    if (args.view === "all") {
        viewAll()
    } else if (args.view === "users") {            //Testing for --view=" "
        viewUsers()
    } else if (args.view === "products") {
        viewProducts()
    }
} else if ('deleteUser' in args) {
    deleteUsers(args)
}
else {
    console.log("invalid command") 
}

