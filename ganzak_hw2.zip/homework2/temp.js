const fs = require('fs')
const minimist = require('minimist')
const { networkInterfaces } = require('os')
const { notDeepStrictEqual } = require ('assert')

function readUsers(){
    //Reading in user.json file
    let inputFile = fs.readFileSync('users.json').toString()
    let users =JSON.parse(inputFile)
    return users
   }
   
   
   function writeUsers(users){
    //Writing to user.json file
    let JSONstr =JSON.stringify(users)
    fs.writeFileSync('users.json',JSONstr)
   }
   
   function addUser(args){
    //This function handles adding in new users to the json file. It checks if theusername is available and if they set a default balance.
    let users = readUsers()
    let user = {}
    let temp = false
    user.name = args.name
    for (let i = 0; i<users.length; i++){ //This loop checks if the current username in args matches any usernames in the .json file.
    if(users[i].userName === args.userName){
    console.log("This username is already taken. Please choose a different one")
    temp = true
    } else {
    temp = false
    }
    }
   if (temp === false) { //Checks if the user defined a balance or not, if no, set the balance of the user to 100 by default
       user.userName = args.userName
   if (args.balance === undefined){
       args.balance = 100
    }
    user.balance = args.balance
    user.items = []
    users.push(user)
    console.log(users)
    writeUsers(users)
    }
   
    }
   
   
   
   function buyItem(args){
    //This function handles purchasing items for users.
    let users = readUsers()
    let user = {}
    let buyerid = -1 //Acts as a counter, if this is still -1 at the end itmeans the buyer does not exist.
    for (let i = 0; i<users.length; i++){
    if(users[i].userName === args.buyer){
    buyerid = i //Checking if username exists
    //console.log("buyer name exists")
    }
    }
    if (buyerid === -1){
    //console.log("Buyer does not exist")
    return
    }
    for (let i = 0; i < users[buyerid].items.length;i++){ //Check if buyer owns item already
    if (users[buyerid].items[i].id === args.id){
    //console.log("Buyer already owns item")
    return
    }
    }
    let sellerid = -1 //These two put variables for the sellersid and the itemid to be accessed later when buyingitems
    let itemindex = -1
    for (let i = 0; i < users.length;i++){
    for (let j = 0; j < users[i].items.length;j++){ //Check ifitem is valid
    if (users[i].items[j].id === args.id){
    sellerid = i
    itemindex = j
    //console.log("Valid seller")
    }
    }
    }
    if (sellerid === -1){
    console.log("Item does not exist!") //Check if item is valid
    return
    }
    if (users[buyerid].balance < users[sellerid].items[itemindex].price){
   //check if they can afford
    console.log("Insufficient funds!")
    return
    }
    console.log("Transaction Sucessfull!")
    users[buyerid].balance -= users[sellerid].items[itemindex].price
   //Subtracting balance from buyer
    users[sellerid].balance += users[sellerid].items[itemindex].price
   //Adding balance to seller
    users[buyerid].items.push(users[sellerid].items[itemindex])
   //Pushing item to buyer
    users[sellerid].items.splice(itemindex,1)
   //Removing item from seller
    console.log(users)
    writeUsers(users)
   }
   function addItems(args){
    //This function handles adding items to the users inventory for selling.
    let users = readUsers()
    let user = {}
    let item = {}
    user.item = args.name
    user.id = Math.floor(Math.random() * 101) //Assign random ID to item
    user.userName = args.owner
    user.price = args.price
    item.name =user.item
    item.price =user.price
    item.id = user.id
    for (let i = 0; i<users.length; i++){ //This for loop checks if the username of the current index is = to the one type in args.
    if(users[i].userName === args.owner){ //If so, push the item into the array
    users[i].items.push(item)
    }
    }
    console.log(users)
    writeUsers(users)
    }
   
   function viewUsers(args){
    //Handles viewing all the users (Not really used/was for testing)
    let users = readUsers()
    let user = {}
    for (let i = 0; i <users.length; i++){ //Display notes at
   index
    console.log(users[i])
    }
   }
   function deleteUsers(){
    //handles deleting users
   let users = readUsers()
   let user = {}
    for (let i = 0; i<users.length; i++){ //This loop runs through the json file and matches the args with the indexed username and splices it out.
    if(users[i].userName === args.userName){
    users.splice(i,1)
    writeUsers(users)
    console.log(users)
    }
    else
    console.log("User does not exist")
    console.log(users)
    }
   }
   
   let args = minimist(process.argv.slice(2),{})
   

   module.exports = {
       addUser,
       buyItem
   }