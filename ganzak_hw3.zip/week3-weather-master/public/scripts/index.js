const weatherForm =document.querySelector('form')
const txtInput=document.querySelector('input')
const txtDisplay=document.querySelector('#wDisplay')

//const summary = require('../../src/app.js')
let test = ''
let finalDistance = 0
let finalTime = 0

weatherForm.addEventListener('submit',(e)=>{
    
    e.preventDefault()

    const place = txtInput.value
    console.log(place)
    fetch('/trip?place='+place).then((response) =>{
        response.json().then((data)=>{
            //console.log(data)
            if (data.error)
                txtDisplay.textContent = 'Could not fetch data'
            else
            for (let i = 0; i < data.legs.length; i++){         //variable holding summary data
                test+='<li>'+' Start:'+data.legs[i].start.name + '<br>'
                test+='Stop:'+data.legs[i].stop.name + '<br>'
                test+='Distance:'+(data.legs[i].distance*0.000621371192).toFixed(3) + ' Miles' + '<br>'
                test+='Time:'+convertTime(data.legs[i].duration) + '</li>' +'<br>'
            }
            for (let i = 0; i < data.legs.length; i++){         //final distance variable
                finalDistance += data.legs[i].distance
            }
            finalDistance = (finalDistance*0.000621371192).toFixed(3)       //convert

            for (let i = 0; i < data.legs.length; i++){     //final time variable
                finalTime += data.legs[i].duration
            } finalTime = convertTime(finalTime)            //convert
            console.log(data)
                //txtDisplay.textContent="Total Distance: "+(data.legs[0].distance*0.000621371192).toFixed(3) + " Miles "+"Total Time: "+ convertTime(data.legs[0].duration)
                txtDisplay.innerHTML=
                '<h2>Your Trip Summary</h2>'+ '<br>'+
                "Total Distance: "+finalDistance + 
                " Miles " + '<br>'  +"Total Time: "+ finalTime + '<br>' 
                + '<ol>'+test+'</ol>' + '<br>' + '<br>'+
                '<b>'+'It is currently '+data.weather.temp+ ' degrees in '+ data.legs[length].stop.name+
                 '. It feels like '+ data.weather.real+ ' degrees.' +'</b>'
                trip = ''
                test = ''           //reset variables
                finalDistance = 0
                finalTime = 0
        })
    })
})



function convertTime(totalSeconds){         //convert time function
let hours = Math.floor(totalSeconds / 3600)
 totalSeconds %= 3600
let minutes = Math.floor(totalSeconds / 60)
let seconds = totalSeconds % 60
return hours + " hours " + minutes + " minutes " + Math.floor(seconds) + " seconds "
}