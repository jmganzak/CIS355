const request= require('request')
const getGeo = (name,cb)=>{
    const geoPrefix='https://api.mapbox.com/geocoding/v5/mapbox.places/'
    const place=name
    const geoKey='pk.eyJ1Ijoiam1nYW56YWsiLCJhIjoiY2wxNzBwdGdyNGJ5MzNvcnBxN3Bqczd6NiJ9.hLCJNxyxxZ-1nLGYHUCIhQ'
    const geoUrl =geoPrefix+place+'.json?access_token='+geoKey

    request({'url': geoUrl},(error,response)=>{
        if(error){
            cb('Unable to access location services',undefined)          //error
        }
        else {
            const data=JSON.parse(response.body)
            if(data.features === undefined){            //match locations
                cb('Invalid Location',undefined)
            }
            else{
            //console.log(data.main.temp)
            const lat = data.features[0].center[1]
            const lon = data.features[0].center[0]  
            const name = data.features[0].place_name
            // console.log('Place : '+ name+' Lat : '+ lat+' Long : '+lon)
            cb(undefined,{lat: lat, lon:lon, name:name})
            }

        }
        
    })
}

module.exports=getGeo