const request = require('request')

const getDriving = (coordinate,callback)=>{
    const drivingPrefix = 'https://api.mapbox.com/directions/v5/mapbox/driving/'
    const drivingKey = 'pk.eyJ1Ijoiam1nYW56YWsiLCJhIjoiY2wxNzBwdGdyNGJ5MzNvcnBxN3Bqczd6NiJ9.hLCJNxyxxZ-1nLGYHUCIhQ'
    const places = coordinate
    const url = drivingPrefix+places+'?access_token='+drivingKey

    request(url,(error,response)=>{
        if (error) {
            callback('service error', undefined)            //service error
        } else {
            const data = JSON.parse(response.body)
            if (data.routes === undefined){
                callback('notvalid location error', undefined)       //Place doesn't exist
            } else {
                callback(undefined,data)        
            }
        }
    })
}

module.exports=getDriving