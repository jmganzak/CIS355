const getGeo = require('./getGeo')
const getWeather = require('./getWeather')
const getDriving = require('./getDriving')

const generateLocations = (addrList, callback)=>{
    console.log(addrList)
    let locations = []
    let count = 0
    for (let item of addrList){     //loop through items of addrList
        getGeo(item,(error,response)=>{
            if (error) {
               console.log(error) 
            }
            else {
                // console.log(response)
                locations.push({idx: addrList.indexOf(item), lat: response.lat, lon: response.lon, name: response.name})        //add id lat lon name to locations array
                count++     //inc count
                if (count === addrList.length){   //if count is = to length of array
                    locations.sort((a,b) => a.idx - b.idx)      //sort
                    console.log(locations)          //display
                    callback(undefined,locations)           
                }
            }

        })
    }
}

const generateTrip = (locations,callback)=>{
    let cord = ''
    for (item of locations){
        cord += (item.lon+'').concat(',', item.lat+'') + ';'        //concact lat and long
    }
    cord = cord.substring(0, cord.length-1)

    getDriving(cord, (error, response)=>{
        if(error){
            console.log(error)
        }else{
            const trip  = {}
            const routes = response.routes[0]
            trip.duration = routes.duration         //pull duration
            trip.distance = routes.distance         //pull distance
            let temp = {}                           //object
            let legs = []                           //array
            for(let i =0; i< routes.legs.length; i++){      //grab route length distance summary
                temp.start = locations[i]               
                temp.stop = locations[i+1]
                temp.distance = routes.legs[i].distance
                temp.duration = routes.legs[i].duration
                temp.summary =  routes.legs[i].summary
                legs.push({...temp})
            }
            trip.legs = legs
            callback(undefined, trip)
        }
    })
}

function tester(){                  //tester function
    generateLocations(['Empire State Building', 'Yankees Stadium', 'Washington Monument'], (error, response)=>{
        if(error){
            console.log(error)
        }else{
            generateTrip(response, (error, result)=>{
                if(error){
                    console.log(error)
                }else{
                     const destination = result.legs[result.legs.length-1].stop
                     getWeather(destination.lat, destination.lon, (error, res) =>{
                        if(error){
                            console.log(error)
                        }else{
                            result.weather = res
                            // console.log(result)
                        }
                     } )
                }
            })
        }
    })
}

//tester()

exports.generateLocations=generateLocations
exports.generateTrip=generateTrip
