/*
function doSomeTask(a,b,cb){
    setTimeout(()=>{
            console.log('Adding a + b')
            const x = a+b
            cb(x)
    },5000)
}

doSomeTask(5,8,saveToFile)

function printResult(result){
    console.log(result)
}

function saveToFile(result){
    //logic to save to file goes here..
}
*/

const request= require('request')
/*
const weatherPrefix='http://api.openweathermap.org/data/2.5/weather?'
const location = ''
const weatherKey= '85cfbb255669b350e054835932ad26e7'
const units='imperial'
const url = weatherPrefix + 'q='+location+'&appid='+weatherKey+'&units='+units

request({'url': url},(error,response)=>{
    const data=JSON.parse(response.body)
    //console.log(data.main.temp)
    const tempInF = data.main.temp 
    console.log('It is currently ' + tempInF+ ' degrees in '+data.name+'. It feels like '+data.main.feels_like+' degrees.')
})
*/

const geoUrl ='https://api.mapbox.com/geocoding/v5/mapbox.places/7400%20Bay%20rd%20Saginaw.json?access_token=pk.eyJ1IjoiYXZpc2hlazMyIiwiYSI6ImNrYTZjNG11MDA1aDkyeHMwNzdvbGlvMmsifQ.qZIqdzcHXLXdUxLlR5rPfw'
request({'url': geoUrl},(error,response)=>{
    const data=JSON.parse(response.body)
    //console.log(data.main.temp)
    const lat = data.features[0].center[1]
    const lon = data.features[0].center[0]
    const name = data.features[0].place_name
    console.log('Place : '+ name+' Lat : '+ lat+' Long : '+lon)

})
    