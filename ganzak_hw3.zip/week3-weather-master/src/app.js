
const express = require('express') //imports express
const path =require('path') //imports path utils
const { resourceLimits } = require('worker_threads')
const getGeo=require('./getGeo')
const getWeather=require('./getWeather')
const {generateTrip} = require('./Trip')
const {generateLocations} = require('./Trip')

const summary = []

let test = ''

//add other imports here

const app = express(); //creates express application and returns an object
const port=3000; //selects the port to be used
app.listen(port) // starts listening for client requests on specified port


app.use(express.static('../public')) //points to static resources like css, client side js etc.
app.set('view engine','ejs') //tells express top use  EJS templating engine
app.set('views',path.join(__dirname,'../views')) //sets the apps view directory 


/* GET index listing. */
app.get('/', (req, res)=> {
    res.render('index')
})

app.get('/trip',(req, res)=> {
    const place  = req.query.place
    const arrayplace = place.split(",")     //split locations by comma
    // console.log(arrayplace)
    generateLocations(arrayplace, (error, response)=>{          //grab locations
        if(error){
            console.log(error)
        }else{
            generateTrip(response, (error, result)=>{       //generate trip
                if(error){
                    console.log(error)
                }else{
                     const destination = result.legs[result.legs.length-1].stop
                     getWeather(destination.lat, destination.lon, (error, resW) =>{     //grab weather
                        if(error){
                            console.log(error)
                        }else{
                            result.weather = resW
                            // console.log(result)
                            res.send(result)                //send over data
                        }
                     } )
                }
            })
        }
    })
})