const request= require('request')
const getWeather=(lat,lon,cb)=>{
    const weatherPrefix='http://api.openweathermap.org/data/2.5/weather?'
    const weatherKey= '272790ff18cb1f48c73532b02854dd9a'
    const units='imperial'
    const url = weatherPrefix + 'lat='+lat+'&lon='+lon+'&appid='+weatherKey+'&units='+units
    request({'url': url},(error,response)=>{
        if(error){
            cb('Unable to access weather services',undefined)
        }
        else{
            const data=JSON.parse(response.body)            //error check
            if(data.main === undefined){
                cb('Invalid location',undefined)
            }
            else{
                 //console.log(data.main.temp)
                const tempInF = data.main.temp 
                //console.log('It is currently ' + tempInF+ ' degrees in '+name+'. It feels like '+data.main.feels_like+' degrees.')
                cb(undefined,{temp: tempInF, real: data.main.feels_like})
            }
           
        }
        
    })
}

module.exports=getWeather