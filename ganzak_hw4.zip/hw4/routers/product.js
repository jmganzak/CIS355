const ejs = require('ejs')
const express = require("express")
const Product = require("../models/product")
const User = require("../models/user")

const router = new express.Router()

router.get('/products',(req,res)=>{         
      
    Product.find({},(error,products)=>{         //find product
        if(error)
            res.send({error:error})
        else{
            let allproducts = []            //store products
            for (let product of products){          //loop through products
                const p = product.toObject()
                allproducts.push(p)             //push product object
            }
            res.send(allproducts)      
        }
    })
})
router.post('/products',(req,res)=>{
    User.find({ user_name: req.body.seller }, (error, user)=>{
    if (error)
    res.send({error:error})
    else {
        let _id = user[0]._id           //grab id
        let p = new Product(
            {
                name: req.body.name,price: req.body.price,owner: _id            //product properties
            }
        )
        p.save((error,result)=>{
            if(error)
            res.send({error:error})         //Errors
        else
            res.send(result)            //send result
          
        })
    }
    })  
})


router.delete('/products/:id',(req,res)=>{          //delete route
    Product.findByIdAndDelete(req.params.id,(error,response)=>{
        if(error)
            res.send({error:error})
        else{
            if(response)
            //success
                res.send({msg:"Product "+req.params.id+" was succesfully deleted."})
            else
            //error
            res.send({msg:"Product "+req.params.id+" could not be located."})
        }
    })
})


router.post('/products/buy', (req,res) =>{      //buy route
    Product.findById(req.body.productID, (error,product) => {
        if (error)
        res.send({error:error})
        else {
            User.find({user_name: req.body.user_name}, (error,buyer)=>{     //find username that matches
                buyer = buyer[0]                
                if (error)
                res.send({error:error})
                else {
                    User.findById(product.owner, (error,seller) => {        //find owner
                        if (error)
                     res.send({error:error})
                     else { 
                         if (buyer.user_name == seller.user_name){      //make sure buyer and seller are not same person
                         res.send({msg:"Oops," + buyer.name + " already owns this item"})
                         } else {
                         if (buyer.balance > product.price ) {      //check balance
                             buyer.balance = buyer.balance - product.price
                             seller.balance = seller.balance + product.price
                             product.owner = buyer._id

                             buyer.save()
                             product.save()     
                             seller.save()
                            res.send({msg:"Transaction successful!"})
                         } else { 
                             res.send({msg: "Oops, " + buyer.name + " has insufficient funds"})      //not enough $$
                         } 
                         }
                        
                     }
                    })
                }
            })
        }
    })
})

module.exports = router