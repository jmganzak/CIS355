const express = require("express")

const User = require("../models/user")
const Product = require('../models/product')

const router = new express.Router()

router.post('/users',(req,res)=>{   //creating new users
    const u = new User(req.body)
    console.log(u)
    u.save((error,response)=>{
        if(error)
                res.send({error:error})
                else{
                    console.log(response)
                    res.send(response)
                }
    })
})

router.get('/users/:user_name',(req,res)=>{     //get username
    console.log(req.params)
    User.find(req.params).populate('items').exec((error,user)=>{        //find user
        console.log(error, user)
        if(error)
            res.send({error:error})
        else
            console.log(user)
            res.send(user)  
    })
})



router.get('/users',(req,res)=>{        //grab users
    User.find({},(error,users)=>{
        if(error)
            res.send({error:error})
        else{
            let allusers=[]         //store users
            for (let user of users){
                const u = user.toObject()
                allusers.push(u)            //push user object 
            }
            res.send(allusers)
            console.log(allusers)
        }
    })
})


router.delete('/users/:user_name',(req,res)=>{          //delete specific user
    User.find(req.params,(error,user)=>{
        user = user[0]
        if(error)
            res.send({error:error})
            if(!user)           //if user does not exist
                res.send({msg:"could not find the user "+req.params.id}) 
                User.findByIdAndDelete(user.id,(error,user)=>{      //find user by id
                    if (error)
                    return res.send ({error:error})
            else
                res.send("Removed" + user)
        })
    })
})


router.get('/summary', (req,res)=> {        //summary route
    User.find({}).populate('items').exec((error,user)=>{
        if(error)
            res.send({error:error})
        else{
            res.send(user)
        }
    })
})

module.exports=router