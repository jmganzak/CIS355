const mongoose = require('mongoose')
const Product = require('./product')

const userSchema = new  mongoose.Schema({           //user schema - name uname bal
    name:{type:String, required:true},
    user_name:{type:String, required:true},
    balance:{type: Number, default:100}
})

userSchema.virtual('items',{                //virutal for product
    ref:'Product',
    localField:'_id',
    foreignField:'owner'
})

userSchema.set('toObject',{virtuals:true})
userSchema.set('toJSON',{virtuals:true})

userSchema.pre('save',function(next){
    console.log("Creating new user...")
    next()
})

userSchema.post('findOneAndDelete',function(user){
    console.log("Deleting user " + user.name)
    if(user){
        Product.deleteMany({owner:user._id},(error,result)=>{
            //console.log(result)
            if(error)
                console.log("error: ",error)
            else
                console.log("results: ",result)
        })
    }
    
})

const User = mongoose.model('User',userSchema,'users')

module.exports = User
