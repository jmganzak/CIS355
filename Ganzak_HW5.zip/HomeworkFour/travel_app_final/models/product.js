
const mongoose = require('mongoose')
const productSchema  = new mongoose.Schema({
    //create schema with properties name,price,owner for products
    name:{type:String, required:true},
    price:{type:Number, required:true},
    owner:{type:mongoose.Schema.Types.ObjectId,ref:'User'}
})

const Product = mongoose.model('Product',productSchema,'products')
module.exports = Product