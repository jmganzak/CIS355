const express = require("express")

const User = require("../models/user")
const bcrypt = require('bcrypt')
const Product = require('../models/product')
const authenticate = require("../middleware")
const router = new express.Router()


router.post('/users/register', async(req,res) => {      //Registering users
    const userr = new User(req.body)
    try {
        const pass = userr.password
        const hashed = await bcrypt.hash(pass,8)        //Get password, username
        userr.password = hashed

        await userr.save()      //save

        const response = {name:userr.name, user_name:userr.user_name, balance:userr.balance, id:userr._id} //fill response
        res.send(response)      //send back response

    } catch(e){
        res.send(e)
    }
    
})


router.post('/users/login', async(req,res)=>{           //Loggin in users
    try {
        const user = await User.findOne({user_name: req.body.user_name})
        if (!user) {
            res.send({msg:"Error loggin in, incorrect username or password"})       //invald credentials message
        }
        const matches = await bcrypt.compare(req.body.password, user.password)      //macthes variables

        if (matches){           //if matches
            req.session.user_id = user._id
            //for testing: console.log('worked')
            res.send({msg: 'Successfully logged in. Welcome '+ user.name}) //welcome new user
        }
        else {
            res.send({msg:'Error logging in, incorrect username or password'})      //invalid login
        }
    } catch (e){
        res.send(e)
    }
})




router.post('/users/logout',authenticate, async(req,res)=>{     //Logout route
    try {
        await req.session.destroy()         //log out and destory session
        res.send({msg: 'Successfully logged out ' + req.user.name})
    }
    catch (e) {
        res.send(e)
    }
})


router.get('/users/me', authenticate, async(req,res)=>{         //grab current user info
    const response = {name: req.user.name, user_name:req.user.user_name, balance: req.user.balance, items: req.user.items}//collect data
    res.send(response)//send it
})


router.get('/summary', async(req,res)=>{ //summary route
    try { 
        const summary = await User.find({}).populate('items')       //Set summary variable with data
        res.send(summary)
    }
    catch (e) {
        res.send(e)
    }
})

router.post('/users',(req,res)=>{
    //creating new users
    const u = new User(req.body)
    u.save((error,response)=>{
        if(error)
                res.send({error:error})
                else{
                    console.log(response)
                   
                    res.send(response)
                }
    })
})

router.delete('/users/me', authenticate, async(req,res)=>{      //delete user
    try {
        await User.findOneAndDelete({user_name:req.user.user_name})     //findbyid to delete based on username matching
        await req.session.destroy()     
        res.send({msg: 'Deleted: ' + req.user.name})        //send message
    }
    catch(e){
        res.send(e)
    }
})


 module.exports=router