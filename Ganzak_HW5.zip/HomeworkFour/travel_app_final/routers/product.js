
const { resolveInclude } = require("ejs")
const express = require("express")
const res = require("express/lib/response")
const Product = require("../models/product")
const User = require("../models/user")
const authenticate = require("../middleware"
)

const router = new express.Router()

router.get('/products', async(req,res)=>{       //products
    try {
        const products = await Product.find({})     //find all products
        let productlist = []        //array
        for (let product of products){      //all products
            const p = product.toObject()        
            productlist.push(p)     //push current index
        }
        res.send(productlist)       //send
    }
    catch (e){
        res.send(e)
    }
})

router.post('/products',authenticate, async(req,res) =>{
    try {

//products
        let product = new Product(      //product specifications
            {
                name: req.body.name,price: req.body.price,owner: req.user._id         
            }
        )
        let presponse = await product.save()      //save product
        res.send(presponse)         //send
    } catch(e) {
        res.send(e)
    }
})


router.delete('/products:id', authenticate, async (req,res)=> {
    const product = await Product.findById(req.params.id)
    //find by the id
    if(product.owner.equals(req.user._id)){         //check for match
        try {
            const response = await Product.findByIdAndDelete(req.params.id) //find and delete
            if (response) {
                res.send({msg: "item" + response.name + " was deleted successfully."}) //Deletion message
            } else {
                res.send({msg: "item" + response.name + " could not be found."})// message on failure
            }
        } catch (e) {
            res.send(e)
        }
    } else {
        res.send({msg: "Unauthorized user for this operation"}) //Invalid user
    }
})

router.post('/products/buy', authenticate, async(req,res)=>{
    try {
        const product = await Product.findById(req.body.productID)
//product
        const buyer = await User.findById(req.session.user_id)
//buyer
        const seller = await User.findById({_id:product.owner})


       // testing: console.log("seller is" + seller)

        if (buyer.user_name == seller.user_name){       //if buyer matches
            res.send({msg: 'Error,' + buyer.name + 'already owns this item'}) //user owns item
        } else {
            if (buyer.balance < product.price){ //if buyer has enough
                res.send({msg: "Error," + buyer.name + "has insufficent balance"})      //Not enough money
            } else {
                buyer.balance = buyer.balance - product.price
                //update buyer

                product.owner = buyer._id//update owner

                seller.balance = seller.balance + product.price//update price

                await product.save()                        //Math/updating product/buyer/seller
                await buyer.save()
                await seller.save()


                res.send({msg: "Purchase complete"})
                //output
            }
        }
    } catch (e){
        res.send(e)
    }
})


module.exports = router