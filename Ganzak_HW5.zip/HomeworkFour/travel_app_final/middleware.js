const User = require("./models/user")
const Product = require("./models/product")

async function authenticateUser(req,res,next){              //Asynce function for authenticating the user
    if (!req.session.user_id){
        res.send({msg: "This page requires you to be logged in"})       //Error msg saying to be logged in
        return res.redirect("/") //redirect on error
    }
    else {
        try {
            const user = await User.findById(req.session.user_id).populate('items')     //Find user
            req.user = user         
            next()      //Move on
        }
        catch(e) {
            res.send(e)     //send error
        }
    }
}


module.exports = authenticateUser